import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { Student } from '../student';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {
  students:Student[]= [];

  constructor(private studentService: StudentService){}

  ngOnInit(): void {
      this.studentService.getAll().subscribe(data => {
        // console.log(data);
        this.students = data;
      })
  }

  deleteStudent(id:number){
      this.studentService.delete(id).subscribe(res => {
        this.students = this.students.filter(n => n.id != id);
        console.log(`Student with id ${id} Deleted Successfully`);
      });
  }
}
