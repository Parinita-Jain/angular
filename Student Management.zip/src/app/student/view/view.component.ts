import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { StudentService } from '../student.service';
import { Student } from '../student';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit{
  id!:number;
  student!: Student;

  constructor(private route:ActivatedRoute,
              private studentService: StudentService){}

  ngOnInit(): void {
    this.id = this.route.snapshot.params['studentId'];
    this.studentService.find(this.id).subscribe(data => {
      this.student = data;
    })
  }
}
