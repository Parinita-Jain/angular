import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { StudentService } from '../student.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  form!:FormGroup;

  constructor(private studentService: StudentService,
              private router: Router,
              private fb: FormBuilder){}

  ngOnInit(): void {
      this.form = this.fb.group({
        name: ['', Validators.required],
        email: ['',[Validators.required,Validators.email]],
        aggregate: ['',[Validators.required, 
                        Validators.min(0), 
                        Validators.max(100)]]
      })
  }

  get f(){
    return this.form.controls;
  }

  submit(){
    console.log(this.form.value);
    this.studentService.create(this.form.value).subscribe(res => {
      console.log("Student Created Successfully");
      this.router.navigateByUrl('student');
    })
  }
}
