import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Student } from './student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  apiURL = "http://localhost:3000";

  constructor(private httpClient: HttpClient) { }

  getAll():Observable<Student[]>{
    return this.httpClient.get<Student[]>(this.apiURL
                                           + "/students/");
  }

  delete(id:number):Observable<Student>{
    return this.httpClient.delete<Student>(this.apiURL
                                            + "/students/" + id);
  }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type' : 'application/json'
    })
  }

  create(student:Student):Observable<Student>{
    return this.httpClient.post<Student>(this.apiURL +"/students/",
                                          JSON.stringify(student), this.httpOptions);
  }        
  
  find(id:number):Observable<Student>{
    return this.httpClient.get<Student>(this.apiURL + "/students/" + id);
  }

  update(id:number, student:Student):Observable<Student>{
    return this.httpClient.put<Student>(this.apiURL + "/students/"+id,
                                          JSON.stringify(student), this.httpOptions);
  }
}   
