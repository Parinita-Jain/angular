export interface Student{
    id:number;
    name:string;
    email:string;
    aggregate:number;
}