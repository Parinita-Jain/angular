import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  id!: number;
  form!:FormGroup;
  student!: Student;

  constructor(private route:ActivatedRoute,
              private fb: FormBuilder,
              private studentService: StudentService,
              private routers: Router){}

  ngOnInit(): void {
    this.id = this.route.snapshot.params['studentId'];
    
    this.studentService.find(this.id).subscribe((data:Student) => {
      this.student = data;
    });

    this.form = this.fb.group({
      name: ['', Validators.required],
      email: ['',[Validators.required,Validators.email]],
      aggregate: ['',[Validators.required, 
                      Validators.min(0), 
                      Validators.max(100)]]
    })
  }

  get f(){
    return this.form.controls;
  }

  submit(){
    console.log(this.form.value);
    this.studentService.update(this.id,this.form.value).subscribe(res =>{
      console.log("Student Updated Successfully");
      this.routers.navigateByUrl('/student');
    })
  }
}
